Default Avatar Images
Place default profile picture options here (avatar1.png, avatar2.png, etc.)
Users can select these as their profile pictures without uploading.
