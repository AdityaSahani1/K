<?php

return [
    'DB_TYPE' => 'sqlite',
    
    'MYSQL_HOST' => 'sql106.infinityfree.com',
    'MYSQL_PORT' => 3306,
    'MYSQL_DATABASE' => 'if0_40098287_snapsera',
    'MYSQL_USERNAME' => 'if0_40098287',
    'MYSQL_PASSWORD' => 'lIHeuEjslJ0',
    
    'SMTP_HOST' => 'smtp.gmail.com',
    'SMTP_PORT' => 587,
    'SMTP_ENCRYPTION' => 'tls',
    'SMTP_USERNAME' => 'snapsera.team@gmail.com',
    'SMTP_PASSWORD' => 'jeie uepk hhjc yrut',
    'SMTP_FROM_EMAIL' => 'snapsera.team@gmail.com',
    'SMTP_FROM_NAME' => 'SnapSera',
    
    'IMGBB_API_KEY' => '5b0c5fa147aae0360e3e798ed5ce37bf',
];
