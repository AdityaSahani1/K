<?php

return [
    'DB_TYPE' => 'sqlite',
    
    'MYSQL_HOST' => 'your-mysql-host.com',
    'MYSQL_PORT' => 3306,
    'MYSQL_DATABASE' => 'your_database_name',
    'MYSQL_USERNAME' => 'your_username',
    'MYSQL_PASSWORD' => 'your_password',
    
    'SMTP_HOST' => 'smtp.gmail.com',
    'SMTP_PORT' => 587,
    'SMTP_ENCRYPTION' => 'tls',
    'SMTP_USERNAME' => 'your-email@gmail.com',
    'SMTP_PASSWORD' => 'your-app-password',
    'SMTP_FROM_EMAIL' => 'your-email@gmail.com',
    'SMTP_FROM_NAME' => 'SnapSera',
];
