<!-- Post Modal - Reusable Component -->
<div class="modal" id="post-modal">
    <div class="modal-content post-modal-content">
        <div class="post-detail" id="post-detail">
            <!-- Post detail content will be loaded dynamically -->
        </div>
    </div>
</div>
